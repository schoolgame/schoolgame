#include<bits/stdc++.h>
#include<conio.h>
using namespace std;
int main()
{
	char g=_getch();
	while(1)
	{
		char ch=_getch();
		cout<<ch<<endl;
	}
}

