#include<bits/stdc++.h>
#include<windows.h>
#include<conio.h>
#define unblock -1 //�߽� 
#define stone 1 //ʯͷ 
#define tree 2 //�� 
#define smtree 3 //С�� 
#define zidan 4 //�ӵ� 
#define zombies '' //��ʬ
#define lifeM 160+8
#define upc ''
#define rightc ''
#define downc ''
#define leftc ''
using namespace std;
int maps[205][205]={},lightmaps[205][205]={},fxy[5][2]={0,0,-1,0,0,1,1,0,0,-1};//70*150
int zidanxy[10000005][5]={},zombiexy[10000005][4]={};
int x=5,y=5,f=1,PC=5,zidanl=1,zidancnt=0,zombiel=1,zombiecnt=0,zombietimes=0;
int blockbestcnt[4],blockup=0,thisblock=1;
int N=50,M=160;
char dictionary[10005]={};
void gotoXY(short x, short y)
{
	x^=y^=x^=y;x--;y--;
    COORD pos = {x, y};
    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleCursorPosition(hOut, pos);
}
void make_map()
{
	system("cls");
	dictionary[0]=' ';
	dictionary[1]=(char)(31);
	dictionary[2]=(char)(46);
	dictionary[3]=(char)(127);
	srand(time(NULL));
	for(int i=1;i<=N;i++)
	{
		for(int j=1;j<=M;j++)
		{
			int g=rand()%50;
			if(g==0)maps[i][j]=stone;
			if(g==1)maps[i][j]=tree;
			if(g==2)maps[i][j]=smtree;
			if(i==1||j==1||i==N||j==M)maps[i][j]=unblock;
			if(i==5&&j==5)maps[i][j]=0;
		}
	}
}
void dellife()
{
	PC--;
	if(PC==0)
	{
		gotoXY(2,M+1);
		printf("   You died...");
		exit(0);
	}
	gotoXY(2,M+1);
	printf("   life:");
	for(int i=1;i<=PC;i++)printf("");
	for(int i=5;i>PC;i--)printf(" ");
}
void printblock(int x,int c)
{
	blockbestcnt[x]+=c;
	gotoXY(2+x+1,M+1);
	printf(" ");
	if(x==thisblock)printf("->");
	else printf("  ");
	printf("block #%d:%d      ",x,blockbestcnt[x]);
}
void nextblock()
{
	gotoXY(2+thisblock+1,M+1);
	printf("   ");
	thisblock=thisblock%3+1;
	gotoXY(2+thisblock+1,M+1);
	printf(" ->");
}
void addsNPC()
{
	zombietimes++;
	if(zombietimes>=100000000)
	{
		int zomx=rand()%N+1,zomy=rand()%M+1;
		if(maps[zomx][zomy]==0&&(!(zomx==x&&zomy==y))&&lightmaps[zomx][zomy]==0)
		{
			zombiecnt++;
			zombiexy[zombiecnt][0]=1;
			zombiexy[zombiecnt][1]=zomx;
			zombiexy[zombiecnt][2]=zomy;
			gotoXY(zomx,zomy);
			putchar(zombies);
			zombietimes=0;
		}
	}
}
void fashe()
{
	zidancnt++;
	zidanxy[zidancnt][1]=x+fxy[f][0];
	zidanxy[zidancnt][2]=y+fxy[f][1];
	if(maps[x+fxy[f][0]][y+fxy[f][1]]!=0)
	{
		zidancnt--;
		return;
	}
	maps[x+fxy[f][0]][y+fxy[f][1]]=zidan;
	zidanxy[zidancnt][3]=f;
	zidanxy[zidancnt][4]=0;
	zidanxy[zidancnt][0]=1;
}
void newpicture()
{
	for(int i=zombiel;i<=zombiecnt;i++)
	{
		if(zombiexy[zombiel][0]==0)
		{
			zombiel++;
			continue;
		}
		int zomx=zombiexy[i][1],zomy=zombiexy[i][2];
		if(zomx<=1||zomx>=N||zomy<=1||zomy>=M)zombiexy[i][0]=0;
		if(zombiexy[i][0])
		{
			int zomflag=0;
			if(zombiexy[i][3]==100000)
			{
				int zx=zomx,zy=zomy;
				if(zx>x)zx--;
				else if(zy<y)zy++;
				else if(zx<x)zx++;
				else if(zy>y)zy--;
				if(maps[zx][zy]==0||maps[zx][zy]==zidan)
				{
					gotoXY(zomx,zomy);
					putchar(' ');
					gotoXY(zx,zy);
					putchar(zombies);
					zombiexy[i][1]=zx;
					zombiexy[i][2]=zy;
					zombiexy[i][3]=0;
				}
				else if(maps[zx][zy]>0&&maps[zx][zy]<=smtree)
				{
					maps[zx][zy]++;
					if(maps[zx][zy]>smtree)maps[zx][zy]=0;
					gotoXY(zx,zy);
					putchar(dictionary[maps[zx][zy]]);
					zombiexy[i][3]=-400000;
				}
			}
			else if(zombiexy[i][3]<100000)zombiexy[i][3]++;
			if(maps[zombiexy[i][1]][zombiexy[i][2]]==zidan)
			{
				zombiexy[i][0]=0;
				continue;
			}
			if(zombiexy[i][1]==x&&zombiexy[i][2]==y)
			{
				dellife();
				zombiexy[i][0]=0;
			}
		}
	}
	for(int i=zidanl;i<=zidancnt;i++)
	{
		if(zidanxy[zidanl][0]==0)
		{
			zidanl++;
			continue;
		}
		if(zidanxy[i][0])
		{
			int zix=zidanxy[i][1],ziy=zidanxy[i][2];
			int zx=zix+fxy[zidanxy[i][3]][0],zy=ziy+fxy[zidanxy[i][3]][1];
			if(zidanxy[i][4]==1000)
			{
				if(maps[zx][zy]!=zidan&&maps[zx][zy]!=0)
				{
					zidanxy[i][0]=0;
					maps[zix][ziy]=0;
					gotoXY(zix,ziy);
					putchar(' ');
					continue;
				}                  
				gotoXY(zix,ziy);
				putchar(' ');
				gotoXY(zx,zy);
				switch(zidanxy[i][3])
				{
					case 1:putchar(upc);break;
					case 2:putchar(rightc);break;
					case 3:putchar(downc);break;
					case 4:putchar(leftc);break;
				}
				zidanxy[i][1]=zx;
				zidanxy[i][2]=zy;
				zidanxy[i][4]=0;
				maps[zix][ziy]=0;
				maps[zx][zy]=zidan;
			}
			else if(zidanxy[i][4]<1000)zidanxy[i][4]++;
		}
	}
	if(++blockup>=100000)
	{
		int x=rand()%N,y=rand()%M;
		if(maps[x][y]>=2&&maps[x][y]<=3)
		{
			maps[x][y]--;
			gotoXY(x,y);putchar(dictionary[maps[x][y]]);
		}
		blockup=0;
	}
}
void newblock()
{
	if(blockbestcnt[thisblock]>0&&maps[x][y]==0)maps[x][y]=thisblock,printblock(thisblock,-1);
}
void newlight()
{
	lightmaps[x][y]=1;
}
void clearblock()
{
	for(int i=1;i<=4;i++)
	{
		int xx=x+fxy[i][0],yy=y+fxy[i][1];
		if(maps[xx][yy]!=unblock&&maps[xx][yy]<=3&&maps[xx][yy]!=0)
		{
			printblock(maps[xx][yy],1);
			if(maps[xx][yy]==1&&rand()%10<=2)printblock(3,1);
			maps[xx][yy]=0;
			gotoXY(xx,yy);
			putchar(' ');
		}
	}
}
int main()
{
	int windowsbigs;
	cout<<"big:1 small:2\n";cin>>windowsbigs;
	CONSOLE_CURSOR_INFO cursor_info = {1, 0}; 
	SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);
	if(windowsbigs==1)system("mode con cols=197 lines=99");
	else system("mode con cols=170 lines=99"),N=40,M=145;
	make_map();
	for(int i=1;i<=N;i++)
	{
		for(int j=1;j<=M;j++)
		{
			switch(maps[i][j])
			{
				case 1:putchar(31);break;
				case 2:putchar(46);break;
				case 3:putchar(127);break;
				case 0:putchar(' ');break;
				case -1:putchar('#');break;
			}
			if(i==5&&j==5)gotoXY(i,j),putchar('');
		}
		if(i==2)printf("   life:");
		putchar('\n');
	}
	printblock(1,0);
	printblock(2,0);
	printblock(3,0);
	while(1)
	{
		addsNPC();
		newpicture();
		if(_kbhit())
		{
			char ch=_getch();
			if(ch=='w')
			{
				f=1;
			}
			else if(ch=='d')
			{
				f=2;
			}
			else if(ch=='s')
			{
				f=3;
			}
			else if(ch=='a')
			{
				f=4;
			}
			else if(ch=='v')
			{
				fashe();
				continue;
			}
			else if(ch=='e')
			{
				newblock();
				continue;
			}
			else if(ch=='q')
			{
				clearblock();
				continue;
			}
			else if(ch=='l')
			{
				newlight();
				continue;
			}
			else if(ch==' ')
			{
				nextblock();
				continue;
			}
			else continue;
			int xx=x+fxy[f][0],yy=y+fxy[f][1];
			if(maps[xx][yy]==0)
			{
				gotoXY(x,y);
				putchar(dictionary[maps[x][y]]);
				gotoXY(xx,yy);
				putchar('');
				x=xx;
				y=yy;
			}
		}
	}
}
